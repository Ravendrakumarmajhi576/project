import Lotory from './Lotory'
import './App.css'
import './Lotory.css'

function App() {
  

  return (
    <>
     
     <Lotory/>
    </>
  )
}

export default App
