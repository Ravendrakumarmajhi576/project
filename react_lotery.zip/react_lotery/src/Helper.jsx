function genTicket(n) {
  let arry = new Array(n);

  for (let i = 0; i < n; i++) {
    arry[i] = Math.floor(Math.random() * 10);
  }

  return arry;
}

function sum(arry) {
  return arry.reduce((total, curr) => total + curr, 0);
}

export { genTicket, sum };
